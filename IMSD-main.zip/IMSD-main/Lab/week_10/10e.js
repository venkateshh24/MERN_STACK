
const wel = require('./welcome');

console.log(wel.wish('Gopi'));




console.log(wel.add());

