function ExternalJS(){
    document.write("Welcome To External JavaScript")
}
